export default {
  navigationBarTitleText: '首页'
}
