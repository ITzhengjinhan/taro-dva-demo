// 请求连接前缀
export const baseUrl = 'https://ms-api.caibowen.net';

// 输出日志信息
export const noConsole = false;
