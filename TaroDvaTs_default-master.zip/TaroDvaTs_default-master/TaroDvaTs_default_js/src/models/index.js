import index from '../pages/index/model'

export default [index]
